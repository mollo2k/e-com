var vrazon_social = {nit: 0, empresa: "desconocido", num_factura: 0, num_autorizacion: 0, cod_control: "", f_l_emision: "05/22/2017"};
var vfacturacion = {fac_rec: true, fecha: "05/20/2017", usuario: ""};
var vgps_lugar = {lote: "", pais: "", region: "", sucursal: ""};

var vventas = new Array(); //array para la tabla ventas
vventas[0] = {precio_unit: 0.00, precio_mayor: 0.00, cant_mayor: 0, descuento_max: 0.00, vende: true};
var vusuario = new Array(); //array para la tabla usuario
vusuario[0] = {personal: "todos", grupos: ""};
var vnumerofila = 0;
//SI EL NAVEGADOR ES CHROME ENTONCES SOLO LA COMA CASO CONTRARIO SOLO PUNTO
var puntcheck = navigator.userAgent.toLowerCase().indexOf('chrome') > -1 ? /[,]/ : /[.]/;


function ffac_rec(vid) { // Factura - Recibo. Funcion...
	var vlabel = document.getElementById("lfactura");
	//var vtableone = document.getElementById("tableone");
	var vcaption = document.getElementById("ctableone");
	if (vid.id == "rfac")	{ // Activar FACTURA
		vlabel.innerHTML = " <b>-Factura:</b>";
		//vtableone.summary = "FACTURA";
		vcaption.innerHTML = "FACTURA";
		document.getElementById("nfactura").placeholder = "# Factura";
		vfacturacion.fac_rec = true;
	}else{ // Activar Recibo
		vlabel.innerHTML = " <b>-Recibo:</b>";
		//vtableone.symmary = "RECIBO";
		vcaption.innerHTML = "RECIBO";
		document.getElementById("nfactura").placeholder = "# Recibo";
		vfacturacion.fac_rec = false;
	}
}


function finicio() {
  var currentTime, vmes, vdia, j, vtab, vfilas, vfilalong, i, vimg, vtabs, vntabs;

// recien agregado
	var currentTime = new Date(); // Recuperar la fecha y formatear.
	var vmes = currentTime.getMonth() + 1;
	var vdia = currentTime.getDate();
	if (vmes < 10)
	{
		vmes = "0" + vmes;
	}
	if (vdia < 10)
	{
		vdia = "0" + vdia;
	}
	var vfecha = currentTime.getFullYear() + "-" + vmes + "-" + vdia;
	document.getElementById("dfecha").value = vfecha;
// recien agregado

  vtab = document.getElementById("tabletwo");
  vfilalong = parseInt(vtab.rows.length);
  for (j = 0; j < vfilalong; j++) {
    for (i = 1; i <= 5; i++) { //onclick a las celdas
      vfilas = vtab.rows[j].cells[i];
      vfilas.onclick = function() {fcrearInput(this);};
    }
  }
  vimg = vtab.rows[j-1].getElementsByTagName("img");
  vimglong = vimg.length - 1;
  for (k = 0; k <= vimglong; k++) { //onclick: anadir fila, eliminar fila
    if (vimg[k].alt == "anadir fila") {
      vimg[k].onclick = function() {fcrearfila(this);};
    }
    else if (vimg[k].alt == "borrar fila") {
      vimg[k].onclick = function() {feliminarfila(this);}; //im.style.visibility = "hidden";
    }
  }

  var vtabventa = document.getElementById("tbventa");
  vfilalongitud = parseInt(vtabventa.rows.length) - 2;
  for (l = 0; vfilalongitud >= l; l++) { //onclick para tabla venta
    vfilaventa = vtabventa.rows[l].cells[1];
    vfilaventa.onclick = function() {fcrearInputv(this);};
  }
  var vcheck = document.getElementById("cvender");
	vcheck.onclick = function() {fcheck(this);};
}

function fcrearInput(celda) { // MODO EDICION
  var obj;
  celda.onclick = function() {return false;};
  //obtener el indice de fila
  vnumerofila = celda.parentNode.rowIndex;
  txt = celda.innerHTML;
  switch (celda.cellIndex) {
    case 1: //Detalle: Mostrar la venta detalle.
      obj = document.getElementById("tbdetalle");
      fmostrar(obj, celda);
      celda.onclick = function() {fcrearInput(celda);};  //activa onclick
      break;
    case 2: //Descripcion
      celda.innerHTML = '';
      obj = celda.appendChild(document.createElement('textarea'));
      obj.rows = "2";
      obj.style.width = "177px";
      obj.style.resize = "none";
      obj.value = txt;
      obj.focus();
      obj.select();
      obj.onblur = function() {
        txt = obj.value;
        celda.removeChild(obj);
        celda.innerHTML = txt;
        celda.onclick = function() {fcrearInput(celda);};  //activa onclick
      };
      break;
    case 3: //Cantidad
      celda.innerHTML = '';
      obj = celda.appendChild(document.createElement('input'));
      obj.type = "number";
      
      obj.step="1";
      obj.title="Introduzca la Cantidad";
      //obj.pattern="^\d+(?:\.\d{1,2})?$";
      
      obj.style.textAlign = "right";
      obj.style.width = "62px";
      obj.min="1";
      obj.value = txt;
      obj.focus();
      obj.select();
      obj.onblur = function() {
        txt = obj.value;
        celda.removeChild(obj);
        celda.innerHTML = txt;
        celda.onclick = function() {fcrearInput(celda);};  //activa onclick
        fcaltotal();
      };
      break;
    case 4: //Venta
      obj = document.getElementById("tbventa");
      fmostrar(obj, celda);
      celda.onclick = function() {fcrearInput(celda);};  //activa onclick
      break;
    case 5: //Usuario
      obj = document.getElementById("tbusuario");
      fmostrar(obj, celda);
      celda.onclick = function() {fcrearInput(celda);};  //activa onclick
      break;
  }
}

function fobtenerPosicion(el) {
  var lx, ly, x, y;
  for (lx = 0, ly = 0; el !== null; lx += el.offsetLeft, ly += el.offsetTop, el = el.offsetParent);
  return {x:lx, y:ly};
}
function fmostrar(vtabla, vcelda) {
  var pos, vancho, valto;
  if (vtabla.style.display == "block") {
    vtabla.style.display = "none";
    return;
  }
  pos = fobtenerPosicion(vcelda);
  vancho = vtabla.offsetWidth;
  valto = vcelda.offsetHeight;
  vtabla.style.left = pos.x + "px";
  vtabla.style.top = (pos.y + valto) + "px";

  ftbdetalleDato(); // Calcular Tabla DETALLE

  if (vtabla.id == "tbventa") { // recuperar array para VENTA
    vtabla.rows[0].cells[1].innerHTML = vventas[vnumerofila].precio_unit;
    vtabla.rows[1].cells[1].innerHTML = vventas[vnumerofila].precio_mayor;
    vtabla.rows[2].cells[1].innerHTML = vventas[vnumerofila].cant_mayor;
    vtabla.rows[3].cells[1].innerHTML = vventas[vnumerofila].descuento_max;
    var vcheck = document.getElementById("cvender");
    vcheck.checked = vventas[vnumerofila].vende;
  }
  vtabla.style.display = "block"; // MOSTRAR TABLA
}

function fcrearfila(obj) {
  fila = obj.parentNode.parentNode; //recuperar handle fila
  vnumerofila = fila.rowIndex;
  vsum = vnumerofila + 1;
  //ordenar la fila
  vtab = fila.parentNode;
  vnfilas = parseInt(vtab.rows.length); //longitud fila
  //vsum += 1;
  for (i = vnfilas; i > vsum; i--) { //ordenar las filas
    vtab.rows[i-1].cells[0].innerHTML = i + 1;
  }
  nuevaFila = fila.cloneNode(true);
  fila.parentNode.insertBefore(nuevaFila, fila);
  im = nuevaFila.getElementsByTagName('img'); //onclick para imagen
  im[0].onclick = function() {fcrearfila(this);};
  im[1].onclick = function() {feliminarfila(this);};

  for (i = 1; i <= 5; i++) { //onclick para las celdas
    nuevaFila.cells[i].onclick = function() {fcrearInput(this);};
  }
  //resetear la fila
  fila.cells[0].innerHTML = vsum + 1; // ITEM
  fila.cells[1].innerHTML = ""; // DETALLE
  fila.cells[2].innerHTML = ""; // DESCRIPCION
  fila.cells[3].innerHTML = "1"; // CANT
  fila.cells[4].innerHTML = "0"; // VENTA
  fila.cells[5].innerHTML = "TODOS"; // USUARIO
  fila.cells[6].innerHTML = "0"; // TOTAL
  //ordenar array para las tablas. Agregar en el array
  vdetalles.splice(vsum, 0, {num_part: "", cod_int: "", categoria: "", img: "", marca: "", detalle: "", made_in: "", descripcion: "", almacen: ""});
  vdetalles[vnumerofila + 1].para = new Array();
  vdetalles[vnumerofila + 1].para[0] = {marca: "", modelo: "", ano: "", obs: ""};
  vventas.splice(vsum, 0, {precio_unit: 0.00, precio_mayor: 0.00, cant_mayor: 0, descuento_max: 0.00, vende: true});
  vusuario.splice(vsum, 0, {personal: "todos", grupos: ""});
}
function feliminarfila(obj) {
  vfila = obj.parentNode.parentNode; //recuperar handle fila
  vtab = vfila.parentNode; //recuperar handle tabla
  if (vtab.rows.length == 1) {return} //si es la unica fila
  vsum = vfila.rowIndex; //indice de la fila seleccionada

  vtab.removeChild(vfila); //eliminar fila

  vfilaslng = parseInt(vtab.rows.length); //longitud fila
  for (i = vsum; vfilaslng > i; i++) { //ordenar las filas
    vtab.rows[i].cells[0].innerHTML = (i + 1);
  }
  //ordenar array para las tablas
  vdetalles.splice(vsum, 1); //elimiar
  vventas.splice(vsum, 1);
  vusuario.splice(vsum, 1);

  fcaltotales();
}
// TABLA VENTA
function fcrearInputv(celda) { //funcion para la tabla venta
  var obj;
  var vfilaindex = celda.parentNode.rowIndex; //index de la fila
  celda.onclick = function() {return false;};
  var txt = parseFloat(celda.innerHTML);
  celda.innerHTML = '';
  obj = celda.appendChild(document.createElement('input'));
  obj.type = "number";
  obj.style.textAlign = "center";
  obj.style.width = "46px";
  obj.oncontextmenu = function() {return false;}; //sin menu-contextual
  obj.value = txt;
  obj.min = "0";
  obj.step = "0.5";
  if (vfilaindex == 2) { // Si es ""cantidad x mayor"", ponerlo entero.
		obj.step = "1";
	}
  obj.focus();
  obj.select();
  obj.onblur = function() { //Al perder el foco.
    txt = parseFloat(obj.value);
    celda.removeChild(obj);
    celda.innerHTML = txt;
    switch (vfilaindex) { //almacenar el contenido de la tabla
      case 0: //Precio unitario
        vventas[vnumerofila].precio_unit = txt;
        document.getElementById("tabletwo").rows[vnumerofila].cells[4].innerHTML = txt;
      break;
      case 1: //Precio por mayor
        vventas[vnumerofila].precio_mayor = txt;
      break;
      case 2: //Cantidad por mayor
        vventas[vnumerofila].cant_mayor = parseInt(txt);
      break;
      case 3: //Descuento Maximo.
        vventas[vnumerofila].descuento_max = txt;
      break;
    }
    fcaltotal();
    celda.onclick = function() {fcrearInputv(celda);};  //activa onclick
  };
  /*restringir solo numeros y el punto
  if (vfilaindex == 0 || vfilaindex == 1 || vfilaindex == 3) {
    obj.onkeypress = function() {
      return fvalidarnum(this, event, true);
      celda.onclick = function() {fcrearInputv(celda);};
    };
  }
  if (vfilaindex == 2) {
    obj.onkeypress = function() {
      return fvalidarnum(this, event, false);
      celda.onclick = function() {fcrearInputv(celda);};
    };
  }
	*/
}
function fvalidarnum(obj, e, vpunto) { //restringir a numeros y puntos
	var keynum = ('which' in event) ? e.which : e.keyCode;
	var keychar = String.fromCharCode(keynum);
	var numcheck = /\d/; //solo digitos 0-9
	//var vunpunto = obj.value.match(/[.]/) ? false : true; //buscar punto
  var vunpunto = vpunto ? (obj.value.match(/[.]/) ? false : true) : false;

	return (numcheck.test(keychar) || puntcheck.test(keychar) && vunpunto);
}
function fcheck(vcheck) {
  vventas[vnumerofila].vende = vcheck.checked;
}

