var video = document.querySelector('video');
var canvas = document.querySelector('canvas');
var ctx = canvas.getContext('2d');
var vimgs = "";
var vTimer;
var localMediaStream = null;

function fsizeCanvas(){
  vTimer = setTimeout(function(){
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
  },100);
}

function fsnapshot() {
  if(video.paused) {
    fsizeCanvas();
    document.querySelector('#bsubir').disabled = true;
    video.play();
    document.querySelector('#bwebcam').textContent = "foto";
    return;
  }
  ctx.drawImage(video, 0, 0);
  vimgs = canvas.toDataURL('image/png');
  video.pause();
  video.poster = vimgs;
  vdetalles[vnumerofila].img = vimgs;
  document.querySelector('#bwebcam').textContent = "webcam";
  document.querySelector('#bsubir').disabled = false;
  //clearInterval(vTimer);
}

function onFailSoHard(e) {
  alert(e.code);
}

document.querySelector('#bwebcam').addEventListener('click', function(e){
  if(localMediaStream){
    fsnapshot();
    return;
  }
  if(navigator.getUserMedia) {
    navigator.getUserMedia('video',function(stream) {
      video.src = stream;
      localMediaStream = stream;
      document.querySelector('#bwebcam').textContent = "foto";
      video.play();
      fsizeCanvas();
    },onFailSoHard);
  }else if(navigator.webkitGetUserMedia){ // CHROME y derivados
    navigator.webkitGetUserMedia({video:true},function(stream){
      video.src = window.webkitURL.createObjectURL(stream);
      localMediaStream=stream;
      document.querySelector('#bwebcam').textContent="fotos";
      video.play();
      fsizeCanvas();
    },onFailSoHard);
  }else if(navigator.mozGetUserMedia){
    navigator.mozGetUserMedia({video:true}, function(stream){
    video.src = stream;
    localMediaStream=stream;
    document.querySelector('#bwebcam').textContent="fotos";
    video.play();
    fsizeCanvas();
    },onFailSoHard);
	}else{
    onFailSoHard({target:video});
  }
}, false);
// Filtro de ficheros. Abrir explorador, para elegir imagen.
document.querySelector('#files').addEventListener('change', function(evt) {
	var vfiles = evt.target.files;
	vreader = new FileReader();
	vreader.onload = function(ev)
	{
		urlBase64 = ev.target.result;
		video.poster = urlBase64;
		vdetalles[vnumerofila].img = urlBase64;
	}
	vreader.readAsDataURL(vfiles[0]);
}, false);
// BOTON "Subir" subir ficheros.
document.querySelector('#bsubir').addEventListener('click', function(e) {
  document.querySelector('#files').click();		// Proboca un click.
  e.preventDefault();
}, false);
