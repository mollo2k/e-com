function fcaltotal() {
	var vtbdos = document.getElementById("tabletwo");
	var vcant = parseFloat(vtbdos.rows[vnumerofila].cells[3].innerHTML);
	var vprecio = parseFloat(vtbdos.rows[vnumerofila].cells[4].innerHTML);
	var vtotal = 0.1;
	vtotal = vcant * vprecio;
	vtbdos.rows[vnumerofila].cells[6].innerHTML = vtotal;
	//vidtotal.value =  vtotal.toFixed(3);
	fcaltotales();
}

function fcaltotales() {
	var vtotal = 0;
	var vtotalu = 0;
	var i = 0;
	var vtbdos = document.getElementById("tabletwo");
	var numfilas = parseInt(vtbdos.rows.length - 1);
	for (i=0; i <= numfilas; i++) {
		vtotal += parseFloat(vtbdos.rows[i].cells[6].innerHTML);
		vtotalu += parseFloat(vtbdos.rows[i].cells[4].innerHTML);
	}

	var vidtotales = document.getElementById("tdtotal");
	vidtotales.innerHTML = vtotal.toFixed(3);
	var vidtotal = document.getElementById("tdventa");
	vidtotal.innerHTML = vtotalu.toFixed(2);
}
