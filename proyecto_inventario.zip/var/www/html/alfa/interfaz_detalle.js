var vdetalles = new Array();
vdetalles[0] = {cod_prod: "", cod_int: "", categoria: "", img: "", marca: "", detalle: "", made_in: "", descripcion: "", almacen: ""};
vdetalles[0].para = new Array();
vdetalles[0].para[0] = {marca: "", modelo: "", ano: "", obs: ""};

var vnumfilap = 0; //REVISAR ESTO NO OLVIDAR

var vtabdetalle = document.getElementById("tbdetalle");
var vtabpara = document.getElementById("tabpara");

function fcrearInputd(celda) { //funcion para tabla detalle
  var obj;
  var vfilaindex = celda.parentNode.rowIndex; //index de la fila
  celda.onclick = function() {return false;};
  var txt = celda.innerHTML;
  celda.innerHTML = '';
  obj = celda.appendChild(document.createElement('input'));
  obj.type = "text";
  obj.style.textAlign = "center";
  obj.style.width = "82px";
  obj.value = txt;
  obj.focus();
  obj.select(); //seleccionar

  obj.onblur = function()
  {
    txt = obj.value;
    celda.removeChild(obj);
    celda.innerHTML = txt;
    switch (vfilaindex) { //almacenar el contenido de la tabla
      case 0:
        vdetalles[vnumerofila].cod_prod = txt;
        break;
      case 1:
        vdetalles[vnumerofila].cod_int = txt;
        break;
      case 2:
        vdetalles[vnumerofila].categoria = txt;
        document.querySelector('#tabletwo').rows[vnumerofila].cells[1].innerHTML = txt;
        break;
      case 3:
        vdetalles[vnumerofila].marca = txt;
        break;
      case 4:
        vdetalles[vnumerofila].detalle = txt;
        break;
      case 5:
        vdetalles[vnumerofila].made_in = txt;
        break;
      case 6:
        vdetalles[vnumerofila].descripcion = txt;
        break;
      case 7:
        vdetalles[vnumerofila].almacen = txt;
        break;
    }
    celda.onclick = function() {fcrearInputd(celda);};  //activa onclick
  };
}

function fcrearInputp(vcelda) { //funcion para la tabla PARA
  vcelda.onclick = function() {return false;}; //IMPORTANTE
  var vIndexFila = vcelda.parentNode.rowIndex - 1; //indice de fila
  var vCeldaIndex = vcelda.cellIndex; //indice de la celda
  vcelda.innerHTML = '';
  var obj = vcelda.appendChild(document.createElement('input'));
  obj.type = "text";
  obj.style.textAlign = "center";
  obj.style.fontSize = "11px";

  switch (vCeldaIndex) { //recuperar del array
    case 0: //celda MARCA
      obj.value = vdetalles[vnumerofila].para[vIndexFila].marca;
      obj.style.width = "65px";
      break;
    case 1: //celda MODELO
      obj.style.width = "65px";
      obj.value = vdetalles[vnumerofila].para[vIndexFila].modelo;
      break;
    case 2: //celda ANO
      obj.style.width = "55px";
      obj.value = vdetalles[vnumerofila].para[vIndexFila].ano;
      break;
    case 3: // celda OBS
      obj.style.width = "60px";
      obj.value = vdetalles[vnumerofila].para[vIndexFila].obs;
      break;
  }

  obj.focus();
  obj.select(); //seleccionar

  obj.onblur = function()
  {
    txt = obj.value;
    vcelda.removeChild(obj);
    vcelda.innerHTML = txt;

    switch (vCeldaIndex) { //almacenar en el array
      case 0:
        vdetalles[vnumerofila].para[vIndexFila].marca = txt;
        break;
      case 1:
        vdetalles[vnumerofila].para[vIndexFila].modelo = txt;
        break;
      case 2:
        vdetalles[vnumerofila].para[vIndexFila].ano = txt;
        break;
      case 3:
        vdetalles[vnumerofila].para[vIndexFila].obs = txt;
        break;
    }
    vcelda.onclick = function() {fcrearInputp(vcelda);};  //activa onclick
  }
}

function fcrearfilap(vobj, vcargar) { //crear fila nueva para la tabla PARA
  var vfila = vobj.parentNode.parentNode; //recuperar handle fila
  var vnumIndex = vfila.rowIndex; //indice de fila
  var vtab = vfila.parentNode; //handle tabla PARA
  var vnuevaFila = vfila.cloneNode(true); //clonar fila
  vtab.insertBefore(vnuevaFila, vfila); // agregar fila

  for (i = 0; 4 > i; i++) { //onclick para las celdas
    vnuevaFila.cells[i].onclick = function() {fcrearInputp(this);};
  }

  var vimg = vnuevaFila.getElementsByTagName('img'); //onclick para imagen
  vimg[0].onclick = function() {fcrearfilap(this, false);};
  vimg[1].onclick = function() {feliminarfilap(this, false);};
  vfila.cells[0].innerHTML = "";
  vfila.cells[1].innerHTML = "";
  vfila.cells[2].innerHTML = "";
  vfila.cells[3].innerHTML = "";
  //agregamos en el array para la tabla PARA
  if (!vcargar) {
    vdetalles[vnumerofila].para.splice(vnumIndex, 0, {marca: "", modelo: "", ano: "", obs: ""});
  }
}
function feliminarfilap(vobj, vcargar) {
  var vfila = vobj.parentNode.parentNode; //recuperar handle fila

  if (vtabpara.rows.length == 2) {alert("fila unica"); return} //si es la unica fila
  var vnumIndex = parseInt(vfila.rowIndex); //numero de la fila seleccionada
  var vtab = vfila.parentNode; //handle de la tabla PARA
  vtab.removeChild(vfila); //eliminar fila

  //ordenar array para las tablas (eliminar un item)
  if (!vcargar) {
    vdetalles[vnumerofila].para.splice(vnumIndex -1, 1);
  }
}

for (k = 0; 8 > k; k++) { //onclick para tabla DETALLE
  vfiladetalles = vtabdetalle.rows[k].cells[1];
  vfiladetalles.onclick = function() {fcrearInputd(this);};
}
//tabla PARA
for (l = 0; 4 > l; l++) { //onclick para tabla PARA
  vfilapara = vtabpara.rows[1].cells[l];
  vfilapara.onclick = function() {fcrearInputp(this);};
}
//agregar fila para la tabla PARA
vimgpara = vtabpara.rows[1].getElementsByTagName("img");
vimgparalong = vimgpara.length - 1; //longitud
for (i = 0; i <= vimgparalong; i++) { //onclick: anadir fila
  if (vimgpara[i].alt == "anadir fila") {
    vimgpara[i].onclick = function() {fcrearfilap(this, false);};
  }
  else if (vimgpara[i].alt == "borrar fila") { //eliminar fila
    vimgpara[i].onclick = function() {feliminarfilap(this, false);};
    //im.style.visibility = "hidden";
  }
}

//CARGAR FILA
function ftbdetalleDato() {
  vtabdetalle.rows[0].cells[1].innerHTML = vdetalles[vnumerofila].cod_prod;
  vtabdetalle.rows[1].cells[1].innerHTML = vdetalles[vnumerofila].cod_int;
  vtabdetalle.rows[2].cells[1].innerHTML = vdetalles[vnumerofila].categoria;
  video.poster = vdetalles[vnumerofila].img;
  vtabdetalle.rows[3].cells[1].innerHTML = vdetalles[vnumerofila].marca;
  vtabdetalle.rows[4].cells[1].innerHTML = vdetalles[vnumerofila].detalle;
  vtabdetalle.rows[5].cells[1].innerHTML = vdetalles[vnumerofila].made_in;
  vtabdetalle.rows[6].cells[1].innerHTML = vdetalles[vnumerofila].descripcion;
  vtabdetalle.rows[7].cells[1].innerHTML = vdetalles[vnumerofila].almacen;

  var vlngrows = vtabpara.rows.length - 1;
  var vlngpara = vdetalles[vnumerofila].para.length;

  for (p = vlngrows; p > vlngpara; p--) { // Eliminar filas sobrantes
    vimg1 = vtabpara.rows[p].getElementsByTagName('img');
    feliminarfilap(vimg1[1], true);
  }
	for (n = (vlngrows); vlngpara > n; n++) { // agregar fila faltante
		vimg2 = vtabpara.rows[n].getElementsByTagName('img');
		fcrearfilap(vimg2[0], true);
	}

  for (m = 1; vlngpara >= m; m++) { // rellenar las filas
    vtabpara.rows[m].cells[0].innerHTML = vdetalles[vnumerofila].para[m - 1].marca;
    vtabpara.rows[m].cells[1].innerHTML = vdetalles[vnumerofila].para[m - 1].modelo;
    vtabpara.rows[m].cells[2].innerHTML = vdetalles[vnumerofila].para[m - 1].ano;
    vtabpara.rows[m].cells[3].innerHTML = vdetalles[vnumerofila].para[m - 1].obs;
  }
}

/*
IMPORTANTE: Agregar nuevo item o array de tabla detalles
vdetalles.splice(1, 0, {cod_prod: "", cod_int: "", marca: "", medida: "", made_in: "", descripcion: "", almacen: "A45"});
vdetalles[1].para = new Array();
vdetalles[1].para[0] = {marca: "", modelo: "", ano: 1800, obs: ""};
*
  //alert(vdetalles[0].para.length);
  var vlongpara = parseInt(vdetalles[vnumerofila].para.length);
  vtabpara.rows[1].cells[0].innerHTML = vdetalles[vnumerofila].para[0].marca;
  vtabpara.rows[1].cells[1].innerHTML = vdetalles[vnumerofila].para[0].modelo;
  vtabpara.rows[1].cells[2].innerHTML = vdetalles[vnumerofila].para[0].ano;
  vtabpara.rows[1].cells[3].innerHTML = vdetalles[vnumerofila].para[0].obs;

  for (m = 1; vlongpara > m; m++) {
    vimg = vtabpara.rows[m].getElementsByTagName('img');
    fcrearfilap(vimg[0], true);
    vtabpara.rows[m+1].cells[0].innerHTML = vdetalles[vnumerofila].para[m].marca;
    vtabpara.rows[m+1].cells[1].innerHTML = vdetalles[vnumerofila].para[m].modelo;
    vtabpara.rows[m+1].cells[2].innerHTML = vdetalles[vnumerofila].para[m].ano;
    vtabpara.rows[m+1].cells[3].innerHTML = vdetalles[vnumerofila].para[m].obs;
  }
 */
