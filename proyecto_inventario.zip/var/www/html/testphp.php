<?php
// Para saber informacion de los modulos PHP
phpinfo(); 
?>
